use std::sync::{Arc, OnceLock};

use vulkano::{
    buffer::{
        allocator::{SubbufferAllocator, SubbufferAllocatorCreateInfo},
        BufferContents, BufferUsage, Subbuffer,
    },
    command_buffer::{
        allocator::{StandardCommandBufferAllocator, StandardCommandBufferAllocatorCreateInfo},
        AutoCommandBufferBuilder, CopyBufferInfoTyped, PrimaryAutoCommandBuffer,
    },
    descriptor_set::{
        allocator::StandardDescriptorSetAllocator, PersistentDescriptorSet, WriteDescriptorSet,
    },
    device::{
        Device, DeviceCreateInfo, DeviceExtensions, Features, Queue, QueueCreateInfo, QueueFlags,
    },
    instance::{Instance, InstanceCreateInfo},
    memory::allocator::{MemoryTypeFilter, StandardMemoryAllocator},
    pipeline::{
        compute::ComputePipelineCreateInfo, layout::PipelineDescriptorSetLayoutCreateInfo,
        ComputePipeline, Pipeline, PipelineLayout, PipelineShaderStageCreateInfo,
    },
    shader::{ShaderModule, SpecializationConstant},
    Version, VulkanLibrary,
};

use ahash::HashMap;

#[derive(Clone, Debug)]
pub struct GpuContext {
    pub device: Arc<Device>,
    pub queue: Arc<Queue>,
    pub memory_allocator: Arc<StandardMemoryAllocator>,
    pub command_buffer_allocator: Arc<StandardCommandBufferAllocator>,
    pub descriptor_set_allocator: Arc<StandardDescriptorSetAllocator>,
    pub subbuffer_host_allocator: Arc<SubbufferAllocator>,
    pub subbuffer_device_allocator: Arc<SubbufferAllocator>,
}

impl GpuContext {
    pub fn new() -> Self {
        let lib = VulkanLibrary::new().unwrap();
        //for layer in lib.layer_properties().unwrap() {
        //    println!("{}, {}", layer.name(), layer.description());
        //}
        //println!("Extensions: {:#?}", lib.supported_extensions());

        let mut instance_create_info = InstanceCreateInfo::default();
        //instance_create_info
        //    .enabled_layers
        //    .push("VK_LAYER_KHRONOS_validation".to_owned());

        instance_create_info.enabled_extensions.ext_debug_utils = false;
        instance_create_info.engine_version = Version {
            major: 1,
            minor: 0,
            patch: 0,
        };

        let instance = Instance::new(lib, instance_create_info).unwrap();

        let phydev = instance
            .enumerate_physical_devices()
            .unwrap()
            .next()
            .unwrap();

        let queue_family_index = phydev
            .queue_family_properties()
            .iter()
            .enumerate()
            .position(|(_queue_family_index, queue_family_properties)| {
                queue_family_properties
                    .queue_flags
                    .contains(QueueFlags::COMPUTE)
            })
            .expect("couldn't find a graphical queue family")
            as u32;

        let device_extensions = DeviceExtensions {
            ..Default::default()
        };

        let device_features = Features {
            ..Default::default()
        };

        let (device, mut queues) = Device::new(
            phydev,
            DeviceCreateInfo {
                // here we pass the desired queue family to use by index
                queue_create_infos: vec![QueueCreateInfo {
                    queue_family_index,
                    ..Default::default()
                }],
                enabled_extensions: device_extensions,
                enabled_features: device_features,
                ..Default::default()
            },
        )
        .expect("failed to create device");

        let queue = queues.next().unwrap();

        let memory_allocator = Arc::new(StandardMemoryAllocator::new_default(device.clone()));

        let command_buffer_allocator = Arc::new(StandardCommandBufferAllocator::new(
            device.clone(),
            StandardCommandBufferAllocatorCreateInfo::default(),
        ));

        let descriptor_set_allocator = Arc::new(StandardDescriptorSetAllocator::new(
            device.clone(),
            Default::default(),
        ));

        let subbuffer_host_allocator = Arc::new(SubbufferAllocator::new(
            memory_allocator.clone(),
            SubbufferAllocatorCreateInfo {
                buffer_usage: BufferUsage::STORAGE_BUFFER
                    | BufferUsage::TRANSFER_SRC
                    | BufferUsage::TRANSFER_DST,
                memory_type_filter: MemoryTypeFilter::PREFER_HOST
                    | MemoryTypeFilter::HOST_SEQUENTIAL_WRITE,
                ..Default::default()
            },
        ));

        let subbuffer_device_allocator = Arc::new(SubbufferAllocator::new(
            memory_allocator.clone(),
            SubbufferAllocatorCreateInfo {
                buffer_usage: BufferUsage::STORAGE_BUFFER
                    | BufferUsage::TRANSFER_SRC
                    | BufferUsage::TRANSFER_DST,
                memory_type_filter: MemoryTypeFilter::PREFER_DEVICE,
                ..Default::default()
            },
        ));

        Self {
            device,
            queue,
            memory_allocator,
            command_buffer_allocator,
            descriptor_set_allocator,
            subbuffer_host_allocator,
            subbuffer_device_allocator,
        }
    }
}

mod cs {
    vulkano_shaders::shader! {
        shaders: {
            emu1: {
                ty: "compute",
                bytes: "shaders/emu1.spv",
            },
        }
    }
}

pub fn get_shader(ctx: &GpuContext, s: &str) -> Option<Arc<ShaderModule>> {
    static SHADERS: OnceLock<Vec<(&str, Arc<ShaderModule>)>> = OnceLock::new();
    SHADERS
        .get_or_init(|| vec![("emu1", cs::load_emu1(ctx.device.clone()).unwrap())])
        .iter()
        .find_map(|(name, module)| {
            if *name == s {
                Some(module.clone())
            } else {
                None
            }
        })
}

pub fn load_shader(
    ctx: &GpuContext,
    name: &str,
    specs: HashMap<u32, SpecializationConstant>,
) -> Arc<ComputePipeline> {
    let shader = get_shader(ctx, name).unwrap().specialize(specs).unwrap();
    let entry = shader.entry_point("main").unwrap();
    let stage = PipelineShaderStageCreateInfo::new(entry);
    let layout = PipelineLayout::new(
        ctx.device.clone(),
        PipelineDescriptorSetLayoutCreateInfo::from_stages([&stage])
            .into_pipeline_layout_create_info(ctx.device.clone())
            .unwrap(),
    )
    .unwrap();

    ComputePipeline::new(
        ctx.device.clone(),
        None,
        ComputePipelineCreateInfo::stage_layout(stage, layout),
    )
    .unwrap()
}

pub fn bind_buffers<T: ?Sized>(
    ctx: &GpuContext,
    pipeline: &Arc<ComputePipeline>,
    buffers: impl IntoIterator<Item = Subbuffer<T>>,
) -> Arc<PersistentDescriptorSet> {
    PersistentDescriptorSet::new(
        &*ctx.descriptor_set_allocator,
        pipeline.layout().set_layouts()[0].clone(),
        buffers
            .into_iter()
            .enumerate()
            .map(|(i, b)| WriteDescriptorSet::buffer(i as u32, b)),
        [],
    )
    .unwrap()
}

pub fn command_buffer_builder<T>(
    ctx: &GpuContext,
    pipeline: &Arc<ComputePipeline>,
    descriptor_set: &Arc<PersistentDescriptorSet>,
    work_group_counts: [u32; 3],
    host_buffer: &Subbuffer<[T]>,
    device_buffer: &Subbuffer<[T]>,
) -> Arc<PrimaryAutoCommandBuffer> {
    let mut builder = AutoCommandBufferBuilder::primary(
        &*ctx.command_buffer_allocator,
        ctx.queue.queue_family_index(),
        vulkano::command_buffer::CommandBufferUsage::OneTimeSubmit,
    )
    .unwrap();

    builder
        .bind_pipeline_compute(pipeline.clone())
        .unwrap()
        .bind_descriptor_sets(
            vulkano::pipeline::PipelineBindPoint::Compute,
            pipeline.layout().clone(),
            0,
            descriptor_set.clone(),
        )
        .unwrap()
        .copy_buffer(CopyBufferInfoTyped::buffers(
            host_buffer.clone(),
            device_buffer.clone(),
        ))
        .unwrap()
        .dispatch(work_group_counts)
        .unwrap()
        .copy_buffer(CopyBufferInfoTyped::buffers(
            device_buffer.clone(),
            host_buffer.clone(),
        ))
        .unwrap();

    builder.build().unwrap()
}

pub fn subbuffer_from_iter<T, I>(allocator: &SubbufferAllocator, iter: I) -> Subbuffer<[T]>
where
    T: BufferContents,
    I: IntoIterator<Item = T>,
    I::IntoIter: ExactSizeIterator,
{
    let iter = iter.into_iter();
    let buffer = allocator
        .allocate_slice(iter.len().try_into().unwrap())
        .unwrap();

    {
        let mut write_guard = buffer.write().unwrap();
        for (p, i) in write_guard.iter_mut().zip(iter) {
            *p = i;
        }
    }

    buffer
}

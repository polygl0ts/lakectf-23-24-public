use elf::{
    abi::{PT_GNU_STACK, PT_LOAD},
    endian::LittleEndian,
    ElfBytes,
};

use crate::{assert, Config};

pub struct MemoryInfo {
    pub entry: u32,
    pub to_alloc: u32,
    pub stack_segment_index: u32,
    pub heap_segment_index: u32,
    pub elf_segments: Vec<Segment>,
}

#[derive(Clone, PartialEq, Eq)]
pub struct Segment {
    pub gpu: GpuSegment,
    pub file_offset: u32,
    pub file_start: u32,
    pub file_len: u32,
}

#[derive(Clone, Default, PartialEq, Eq)]
pub struct GpuSegment {
    pub perms: u32,
    pub emu_start: u32,
    pub emu_len: u32,
    pub phy_start: u32,
}

impl MemoryInfo {
    pub fn from_file_bytes(bytes: &[u8], config: &Config) -> MemoryInfo {
        let elf = ElfBytes::<LittleEndian>::minimal_parse(bytes).unwrap();

        let entry = elf.ehdr.e_entry as u32;

        let mut mem_info = MemoryInfo {
            entry,
            to_alloc: 0,
            stack_segment_index: 0,
            heap_segment_index: 1,
            elf_segments: vec![],
        };

        let mut phy_alloc = config.segment_phy_base * 4;
        mem_info.elf_segments.push(Segment {
            gpu: GpuSegment {
                perms: 6,
                emu_start: config.stack_addr_emu,
                emu_len: config.stack_len,
                phy_start: phy_alloc,
            },
            file_offset: 0,
            file_start: 0,
            file_len: 0,
        });
        phy_alloc += config.stack_len;

        mem_info.elf_segments.push(Segment {
            gpu: GpuSegment {
                perms: 6,
                emu_start: config.heap_addr_emu,
                emu_len: config.heap_len,
                phy_start: phy_alloc,
            },
            file_offset: 0,
            file_start: 0,
            file_len: 0,
        });
        phy_alloc += config.heap_len;

        for seg in elf.segments().unwrap() {
            match seg.p_type {
                PT_LOAD => {
                    let perms = seg.p_flags;
                    let pad_start = seg.p_vaddr % seg.p_align;
                    let emu_start = (seg.p_vaddr - pad_start).try_into().unwrap();
                    let emu_end: u32 = (seg.p_vaddr + seg.p_memsz)
                        .next_multiple_of(seg.p_align)
                        .try_into()
                        .unwrap();
                    let emu_len = emu_end.checked_sub(emu_start).unwrap();

                    let phy_start = phy_alloc;
                    phy_alloc += emu_len;

                    let file_offset = seg.p_offset.try_into().unwrap();
                    let file_start =
                        TryInto::<u32>::try_into(seg.p_vaddr).unwrap() - emu_start + phy_start;
                    let file_len = seg.p_filesz.try_into().unwrap();

                    mem_info.elf_segments.push(Segment {
                        gpu: GpuSegment {
                            perms,
                            emu_start,
                            emu_len,
                            phy_start,
                        },
                        file_offset,
                        file_start,
                        file_len,
                    });
                }
                PT_GNU_STACK => {}
                _ => (),
            }
        }

        mem_info.to_alloc = phy_alloc;
        mem_info
    }

    pub fn emu_to_phy(&self, emu: u32) -> Option<u32> {
        let mut ret = None;
        for s in &self.elf_segments {
            if let Some(phy) = s.gpu.emu_to_phy(emu) {
                assert(ret.is_none());
                ret = Some(phy);
            }
        }
        ret
    }

    pub fn phy_to_emu(&self, phy: u32) -> Option<u32> {
        let mut ret = None;
        for s in &self.elf_segments {
            if let Some(emu) = s.gpu.phy_to_emu(phy) {
                assert(ret.is_none());
                ret = Some(emu);
            }
        }
        ret
    }
}

impl GpuSegment {
    pub fn emu_to_phy(&self, emu: u32) -> Option<u32> {
        if emu < self.emu_start {
            return None;
        }
        let off = emu - self.emu_start;
        if off >= self.emu_len {
            return None;
        }
        Some(self.phy_start + off)
    }

    pub fn phy_to_emu(&self, phy: u32) -> Option<u32> {
        if phy < self.phy_start {
            return None;
        }
        let off = phy - self.phy_start;
        if off >= self.emu_len {
            return None;
        }
        Some(self.emu_start + off)
    }
}

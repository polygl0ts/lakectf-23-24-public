use std::ops::{Deref, DerefMut};

use crate::memory::GpuSegment;

#[derive(Clone, Default)]
pub struct EmuState {
    pub error: u32,
    pub pc: u32,
    pub x: Regs,
    pub instr_count: u32,
    pub brk_val: u32,
    pub segments: Vec<GpuSegment>,
}

impl EmuState {
    pub fn for_each_field(&mut self, mut f: impl FnMut(&mut u32)) {
        let EmuState {
            error,
            pc,
            x,
            instr_count,
            brk_val,
            segments,
        } = self;
        f(error);
        f(pc);
        for reg in x.iter_mut() {
            f(reg);
        }
        f(instr_count);
        f(brk_val);
        for GpuSegment {
            perms,
            emu_start,
            emu_len,
            phy_start,
        } in segments.iter_mut()
        {
            f(perms);
            f(emu_start);
            f(emu_len);
            f(phy_start);
        }
    }
}

#[derive(Default, Clone)]
pub struct Regs(pub [u32; 32]);

impl Deref for Regs {
    type Target = [u32; 32];

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl DerefMut for Regs {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.0
    }
}

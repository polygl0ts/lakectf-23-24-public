use std::{
    io::{stdout, Read, Write},
    sync::OnceLock,
};

use crate::context::Context;

pub fn emu_syscall(ctx: &mut Context) -> bool {
    let x = &ctx.emu_state.x;
    let n = x[17];

    let Some(syscall) = get_syscall_table().get(n as usize) else {
        return false;
    };
    syscall(ctx)
}

type SyscallTable = [fn(&mut Context) -> bool; 512];

fn get_syscall_table() -> &'static SyscallTable {
    static TABLE: OnceLock<SyscallTable> = OnceLock::new();

    fn not_impl(ctx: &mut Context) -> bool {
        // Fail the syscall
        ctx.emu_state.x[10] = -38i32 as u32;
        ctx.emu_state.x[11] = 0;
        true
    }

    fn success(ctx: &mut Context) -> bool {
        // Return 0
        ctx.emu_state.x[10] = 0;
        ctx.emu_state.x[11] = 0;
        true
    }

    fn fail(_: &mut Context) -> bool {
        false
    }

    fn sys_read(c: &mut Context) -> bool {
        let fd = c.emu_state.x[10];
        let buf = c.emu_state.x[11];
        let buflen = c.emu_state.x[12];

        if fd != 0 {
            return false;
        }

        let mut tmp_buf = vec![0; buflen as usize];

        let mut stdin = std::io::stdin().lock();
        match stdin.read(&mut tmp_buf) {
            Ok(n) => {
                c.write_heap_emu(buf, &tmp_buf[..n]).unwrap();

                c.emu_state.x[10] = n.try_into().unwrap();
                c.emu_state.x[11] = 0;
                return true;
            }
            Err(_) => {
                return false;
            }
        }
    }

    fn sys_write(c: &mut Context) -> bool {
        let fd = c.emu_state.x[10];
        let buf = c.emu_state.x[11];
        let buflen = c.emu_state.x[12];

        if fd != 1 && fd != 2 {
            return false;
        }

        let mut data = vec![0; buflen as usize];
        c.read_heap_emu(buf, &mut data).unwrap();

        match String::from_utf8(data) {
            Ok(sdata) => {
                print!("{}", sdata);
                stdout().flush().unwrap();
            }
            Err(e) => {
                let bs = e.into_bytes();
                eprintln!("fd={fd} --------\n{:?}\n--------", bs);
                stdout().write_all(&bs).unwrap();
            }
        }

        c.emu_state.x[10] = buflen;
        c.emu_state.x[11] = 0;
        true
    }

    TABLE.get_or_init(|| {
        let mut systable: SyscallTable = [fail; 512];
        systable[63] = sys_read;
        systable[64] = sys_write;
        systable[94] = fail;
        systable
    })
}

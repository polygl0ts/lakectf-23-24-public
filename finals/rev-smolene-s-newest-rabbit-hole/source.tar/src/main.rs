#![allow(dead_code)]

mod context;
mod emu_state;
mod gpu_context;
mod memory;
mod syscall;

use std::env::args;

use syscall::emu_syscall;

use crate::context::Context;

static THEBYTES: &[u8] = include_bytes!("../thebytes");

fn main() {
    let wait = if let Some(arg) = args().find(|s| s.starts_with("--wait=")) {
        arg.split_once("=")
            .expect("Expected count after --wait")
            .1
            .parse::<u32>()
            .expect("Failed to parse --wait=")
    } else {
        0x10000
    };

    let bytes = THEBYTES.to_vec();

    let config = Config {
        send_base: 0x0000,
        segment_phy_base: 0x40000,
        stack_addr_emu: 0x4000000,
        stack_len: 0x8000,
        heap_addr_emu: 0x1000000,
        heap_len: 0x400000,
        work_group_size: 1,
    };

    let mut ctx = Context::new(bytes, config, wait);

    run_loop(&mut ctx);
}

fn run_loop(ctx: &mut Context) {
    ctx.load_segments();

    loop {
        ctx.send();
        ctx.run([1, 1, 1]);
        ctx.recv();

        if ctx.emu_state.error == 0x100 {
            if !emu_syscall(ctx) {
                break;
            }
            ctx.emu_state.error = 0;
            ctx.emu_state.pc += 4;
            ctx.emu_state.instr_count += 1;
        } else if ctx.emu_state.error == 512 {
            ctx.emu_state.error = 0;
            continue;
        } else {
            break;
        }
    }
}

#[derive(Clone)]
struct Config {
    send_base: u32,
    segment_phy_base: u32,
    stack_addr_emu: u32,
    stack_len: u32,
    heap_addr_emu: u32,
    heap_len: u32,
    work_group_size: u32,
}

pub fn assert(b: bool) {
    if !b {
        panic!();
    }
}

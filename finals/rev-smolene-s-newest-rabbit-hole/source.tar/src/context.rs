use std::{
    sync::Arc,
    time::{Duration, Instant},
};

use ahash::HashMap;
use vulkano::{
    buffer::Subbuffer,
    descriptor_set::PersistentDescriptorSet,
    pipeline::ComputePipeline,
    shader::SpecializationConstant,
    sync::{self, GpuFuture as _},
};

use crate::{
    assert,
    emu_state::{EmuState, Regs},
    gpu_context::{bind_buffers, command_buffer_builder, load_shader, GpuContext},
    memory::MemoryInfo,
    Config,
};

pub struct Context {
    pub config: Config,
    pub gpu: GpuContext,
    pub mem: MemoryInfo,
    pub bytes: Vec<u8>,
    pub host_buffer: Subbuffer<[u32]>,
    pub device_buffer: Subbuffer<[u32]>,
    pub pipeline: Arc<ComputePipeline>,
    pub descriptor_set: Arc<PersistentDescriptorSet>,
    pub emu_state: EmuState,
}

impl Context {
    pub fn new(bytes: Vec<u8>, config: Config, wait: u32) -> Self {
        let gpu = GpuContext::new();
        let mem = MemoryInfo::from_file_bytes(&bytes, &config);
        let host_buffer = gpu
            .subbuffer_host_allocator
            .allocate_slice(mem.to_alloc.next_multiple_of(4) as u64 / 4)
            .unwrap();
        let device_buffer = gpu
            .subbuffer_device_allocator
            .allocate_slice(host_buffer.len())
            .unwrap();

        host_buffer.write().unwrap().fill(0);

        let heap_seg = &mem.elf_segments[mem.heap_segment_index as usize];

        let pipeline = load_shader(
            &gpu,
            "emu1",
            HashMap::from_iter([
                (0, SpecializationConstant::U32(config.work_group_size)),
                (11, SpecializationConstant::U32(config.send_base)),
                (
                    12,
                    SpecializationConstant::U32(mem.elf_segments.len() as u32),
                ),
                (18, SpecializationConstant::U32(heap_seg.gpu.emu_start)),
                (
                    19,
                    SpecializationConstant::U32(heap_seg.gpu.emu_start + heap_seg.gpu.emu_len),
                ),
                (20, SpecializationConstant::U32(wait)),
            ]),
        );
        let descriptor_set = bind_buffers(&gpu, &pipeline, [device_buffer.clone()]);

        let emu_state = EmuState {
            error: 0,
            pc: mem.entry,
            x: Regs([0; 32]),
            instr_count: 0,
            brk_val: heap_seg.gpu.emu_start,
            segments: mem.elf_segments.iter().map(|s| s.gpu.clone()).collect(),
        };

        Self {
            config,
            gpu,
            mem,
            bytes,
            host_buffer,
            device_buffer,
            pipeline,
            descriptor_set,
            emu_state,
        }
    }

    pub fn load_segments(&mut self) {
        let mut w = self.host_buffer.write().unwrap();
        let mut ww = move |i: usize, v: u32| {
            w[i] = v;
        };

        let argv = vec!["/program".to_string()];

        let argv_bytes: usize = argv.iter().map(|s| s.len() + 4).sum();
        assert(argv_bytes < 0x1000);

        let stack_seg = &self.mem.elf_segments[self.mem.stack_segment_index as usize];
        let sp = (stack_seg.gpu.emu_start + stack_seg.gpu.emu_len - 0x100 - argv_bytes as u32)
            .next_multiple_of(4)
            - 4;
        self.emu_state.x[2] = sp;

        let mut spa = (stack_seg.gpu.emu_to_phy(sp).unwrap() >> 2) as usize;

        let randseed = [0xcafebabe, 0xdeadbeef, 0xcaca1337, 0xfeddad42];

        let argc = argv.len();

        ww(spa, argc as u32);
        spa += 1;

        let argv_start = spa;
        spa += argc;
        ww(spa, 0); // NULL last argv
        spa += 1;

        ww(spa, 0); // NULL last envp
        spa += 1;

        let at_random_start = spa;
        ww(spa, 25); // AT_RANDOM
        spa += 2;

        ww(spa, 0); // AT_NULL
        ww(spa + 1, 0); // AT_NULL value
        spa += 2;

        ww(
            at_random_start + 1,
            stack_seg.gpu.phy_to_emu((spa as u32) << 2).unwrap(),
        ); // fixup AT_RANDOM value
        for i in 0..4 {
            ww(spa + i, randseed[i]);
        }
        spa += 4;

        for (i, arg) in argv.iter().enumerate() {
            ww(
                argv_start + i,
                stack_seg.gpu.phy_to_emu((spa as u32) << 2).unwrap(),
            );
            for bs in arg.as_bytes().chunks(4) {
                let mut tmp = [0u8; 4];
                (&mut tmp[..bs.len()]).copy_from_slice(bs);
                ww(spa, u32::from_le_bytes(tmp));
                spa += 1;
            }
            ww(spa, 0);
            spa += 1; // padding for \0
        }

        for seg in self.mem.elf_segments.iter() {
            assert((seg.file_start & 3) == 0);

            let file_offset = seg.file_offset as usize;
            let file_start = (seg.file_start / 4) as usize;
            let file_len = seg.file_len as usize;

            for i in 0..file_len / 4 {
                let idx = file_offset + i * 4;
                let v = u32::from_le_bytes(self.bytes[idx..idx + 4].try_into().unwrap());
                ww(file_start + i, v);
            }

            let rem = file_len % 4;
            if rem != 0 {
                let mut buf = [0u8; 4];
                for (i, fi) in (file_len - rem..file_len).enumerate() {
                    buf[i] = self.bytes[fi];
                }
                ww(file_start + file_len / 4, u32::from_le_bytes(buf));
            }
        }
    }

    pub fn send(&mut self) {
        let mut heap = self.host_buffer.write().unwrap();

        self.emu_state.segments.clear();
        self.emu_state
            .segments
            .extend(self.mem.elf_segments.iter().map(|s| &s.gpu).cloned());

        let mut idx = self.config.send_base as usize;
        self.emu_state.for_each_field(|field| {
            heap[idx] = *field;
            idx += 1;
        });
    }

    pub fn recv(&mut self) {
        let heap = self.host_buffer.read().unwrap();

        let mut idx = self.config.send_base as usize;
        self.emu_state.for_each_field(|field| {
            *field = heap[idx];
            idx += 1;
        });

        assert(
            self.emu_state
                .segments
                .iter()
                .zip(self.mem.elf_segments.iter())
                .all(|(l, r)| l == &r.gpu),
        );
    }

    pub fn run(&self, work_group_count: [u32; 3]) -> Duration {
        let command_buffer = command_buffer_builder(
            &self.gpu,
            &self.pipeline,
            &self.descriptor_set,
            work_group_count,
            &self.host_buffer,
            &self.device_buffer,
        );

        let future = sync::now(self.gpu.device.clone())
            .then_execute(self.gpu.queue.clone(), command_buffer)
            .unwrap()
            .then_signal_fence_and_flush()
            .unwrap();

        let before = Instant::now();
        future.wait(None).unwrap();
        Instant::now().duration_since(before)
    }

    pub fn get_brk(&self) -> u32 {
        let s = &self.mem.elf_segments[self.mem.heap_segment_index as usize].gpu;
        s.emu_start + s.emu_len
    }

    pub fn set_brk(&mut self, new_brk: u32) -> bool {
        let s = &mut self.mem.elf_segments[self.mem.heap_segment_index as usize].gpu;
        let heap_end = s.emu_start + self.config.heap_len;
        if s.emu_start <= new_brk && new_brk <= heap_end {
            s.emu_len = new_brk - s.emu_start;
            true
        } else {
            false
        }
    }

    pub fn read_heap_phy(&self, phy: u32, out: &mut [u8]) -> Result<(), ()> {
        // FIXME: make this more efficient and safe!! currently doesnt bounds check that phy is in
        // a single segment...
        let h = self.host_buffer.read().unwrap();
        let get_byte = |phy: usize| -> u8 {
            let to_shift = (phy & 0x3) << 3;
            let phy32 = phy >> 2;
            (h[phy32] >> to_shift) as u8
        };

        for (i, b) in out.into_iter().enumerate() {
            *b = get_byte(phy as usize + i);
        }

        Ok(())
    }

    pub fn read_heap_emu(&self, emu: u32, out: &mut [u8]) -> Result<(), ()> {
        // FIXME: Check perms
        self.read_heap_phy(self.mem.emu_to_phy(emu).ok_or(())?, out)
    }

    pub fn write_heap_phy(&mut self, phy: u32, input: &[u8]) -> Result<(), ()> {
        let mut h = self.host_buffer.write().unwrap();
        let mut set_byte = |phy: usize, b: u8| {
            let off = (phy & 3) << 3;
            let mask = 0xff << off;
            let phy32 = phy >> 2;
            h[phy32] = (h[phy32] & !mask) | ((b as u32) << off);
        };

        for (i, b) in input.into_iter().enumerate() {
            set_byte(phy as usize + i, *b);
        }

        Ok(())
    }

    pub fn write_heap_emu(&mut self, emu: u32, input: &[u8]) -> Result<(), ()> {
        // FIXME: Check perms
        self.write_heap_phy(self.mem.emu_to_phy(emu).ok_or(())?, input)
    }
}

// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

contract Challenge {
    event CallMe(address target, bytes4 selector);

    function testFlag(string memory flag) external pure returns (bool) {
        return keccak256(bytes(flag)) == hex"d0197e7acaa40d064467b26cf928e8e5d73fbcfbcbae2772b6a1f6b2fe63423c";
    }

    function callme(address target, bytes4 selector) external {
        emit CallMe(target, selector);
    }
}
